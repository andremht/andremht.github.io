addpath('Quad Tank system');
% addpath('Solutions');

clear; clc;

%% setup the system model, controller, and detector
% the defualt setting of the plant is non-minimum phase. This means that
% u_1 is more strongly coupled to y_2 that to y_1, and u_2 to y_1 than to y_2.
% There is also one unstable zero from u to y.

flag_noise = 1;
initialize_closed_loop_system % you do not need to look into this function

%% Set the noise in the Simulink environment
if flag_noise == 0
    Qn=eye(size(G,2))*0;
    Rn = eye(p)*0;  
end

%% Fetch the matrices of the CT and DT systems.
% Now you can obtain the continuous- and discrete-time models of the plant
% and also the controller and observer.

[A,B,C,D] = ssdata(sysmp); % CT model of the plant

[Ad,Bd,Cd,Dd] = ssdata(sysmp_d); % DT model of the plant
Ts = sysmp_d.Ts;


%% For Scenario 2 (attack at actuator 1), here we obtain the closed-loop system model, from attack signal to performance and detection outputs.
% The output of the script below is required for implementing Scenario 2 in the
% Computer Exercises.
% Outside of the assignment, you are welcome to modify the code for other senarios


get_closed_loop;
% returns the following systems:
% * sys; % is the full system
% * sys_p = [eye(n), zeros(n,m)]*sys; % is the performance subsystem, from a to y_p
% * sys_r = [zeros(m,n), eye(m)]*sys; % is the detection subsystem, from a to y_r



%% This part generates the reference, disturbance, faults, and attack signals
% for the assignments, all the flags should be set to 0 unless specified
% otherwise.
%
% if you want to get some intuition about the process, try out some
% reference change or disturbance.

%% Disturbances and Faults
flag_pulse_disturbance =0; % 1 enables the pulse disturbance

flag_leakage_fault =0; % 0 disables the leakage fault
flag_actuator_fault =0; % 0 disables the actuator fault
flag_sensor_fault =0; % 0 disables the sensor fault

%%%%%

mag_pulse_disturbance = 2; % magnitude of the disturbance, corresponds to (a scale version of) the volume of water added to the tank.

mag_leakage_fault = 0.5; % magnitude of the fault. 0 means no fault, 1 means 100%.
mag_actuator_fault = 0.1; % magnitude of the fault. 1 corresponds to a 100% (full) loss of the actuator.
mag_sensor_fault = 0.1; % magnitude of the fault. 1 corresponds to a 100% (full) loss of the sensor.

df_start = 700; %start time of the disturbance / faults
% Note: all faults and disturbances are set to start at t=df_start.

%% Reference changes

flag_reference_change = 0; % 1 enables the pulse reference, 0 disables.



%% genererate the required signals
generate_signals %% this script generates the reference and the unknown signals (disturbance / faults)

%% Set the attack signals - MODIFY CODE IN THE SCRIPT BELOW
% NOTE: modify the script below to implement youur attack signals in the
% Simulink model, and to activate the attack scenario through the
% corresponding flag.
set_attacks;

%% open simulink model

run closedloop_LQG_nonlinear_under_Faults % uncomment to open the Simulink environment.

%% run the simulink model
simOut = sim('closedloop_LQG_nonlinear_under_Faults'); % runs the Simulink environment.


%% Plots of relevant measured / known signals
close all %close all figures, to avoid plotting multiople runs on top of each other.

% measurements and references
figure(1)
hold on
plot(measurement,'LineWidth', 1.5)
plot(reference, ':', 'LineWidth', 2)
hold off
legend('$y_1$', '$y_2$', '$r_1$', '$r_2$','fontsize',14,'interpreter','latex')
title('Measurement signals and References', 'fontsize',14)

%% control signals

figure(2)
hold on
plot(control_signal,'LineWidth', 1.5)
plot(control_signal.time, ub*ones(1,length(control_signal.time)), 'b:', 'LineWidth', 1) % upper limit of the tank, at 25cm
plot(control_signal.time, ul*ones(1,length(control_signal.time)), 'b:', 'LineWidth', 1) % lower limit of the tank, at 0cm
hold off
ylim([-5, 20])
legend('$u_1$', '$u_2$', 'fontsize',14,'interpreter','latex')
title('Control signals', 'fontsize',14)

%% residuals
figure(3)
plot(residuals,'LineWidth', 1.5)
legend('$res_1$', '$res_2$', 'fontsize',14,'interpreter','latex')
title('Residual signals', 'fontsize',14)

res_peak = [];
for i=1:1:length(residuals.time)
res_peak = [res_peak norm(residuals.data(:,:,i),2)];
end

thres = 0.25*ones(1,length(residuals.time));

figure(4)
plot(residuals.time,res_peak,'LineWidth', 1.5)
hold on
plot(residuals.time, thres, '--', 'LineWidth', 1)
hold off
ylim([0, 0.35])
legend('$\|y_r[k]\|_2$', 'fontsize',14,'interpreter','latex')
title('Instantenous Norm Residual Signals', 'fontsize',14)

%% Plots of unmeasured signals

figure(5)
hold on
plot(state_signals,'LineWidth', 1.5)
plot(state_signals.time, 25*ones(1,length(state_signals.time)), 'b:', 'LineWidth', 1) % upper limit of the tank, at 25cm
plot(state_signals.time, zeros(1,length(state_signals.time)), 'b:', 'LineWidth', 1) % lower limit of the tank, at 0cm
hold off
ylim([-5, 30])
legend('$h_1$', '$h_2$', '$h_3$', '$h_4$', 'fontsize' ,14,'interpreter','latex')
title('Water levels', 'fontsize',14)
