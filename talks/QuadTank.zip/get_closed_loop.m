%% Construct the closed-loop system model, from attack signal to performance and detection outputs
% This will be done in three steps: 1) plant, 2) controller and detector ;
% 3) closed-loop using 'lft'

%% 1) Construct the plant under attack
% The discretized plant model augmented with iintegral states is stored in 'sysmp_aug_d'

% First we add the attack channels as inputs. We will be usiing the
% function 'lft' later on, so the external inputs must come first.

% The case when actuator 1 is attacked is encoded as:
B_sys = [sysmp_aug_d.b(:,1) sysmp_aug_d.b];

% Then we extend the C and D matrices so that the plant gives as outputs 
% y_sys1 = [x; u ; y; e_int];
% This structure id needed due to the use of 'lft', the first outputs channels of
% the plant will be the external output of the closed-loop system - we
% want this to be the physical states, from whiich we capture performance.

C_sys = [eye(n), zeros(n,p); 
        zeros(m,n+p);
        sysmp_aug_d.c];

% we modify D accordingly to the changes to C_sys and B_sys.
D_sys = [zeros(n,m+1);
        [zeros(m,1) eye(m)];
        [zeros(2*p, 1) sysmp_aug_d.d]];

% Now we construct the plant model with inputs [a_u ; u] and outputs [x; u ; y; e_int]
sysmp_int_states_attack_d = ss(sysmp_aug_d.a, B_sys , C_sys, D_sys, Ts);

%% 2) Construct the feedback controller and anomaly detector
% kest is the Kalman filter with inputs [u;y] and outputs [yhat; xhat]
% Klq is the LQRi gain, where u = -Klq*[xhat ; e_int];

% First we prepare the estimator, so that it receives as inputs u_sys2 = [u ; y ;
% e_int], and provides as outputs y_sys_kest = [yhat; xhat ; e_int ; y]
sys_kest = [[kest zeros(n+p, p)];
                zeros(p,m), zeros(p, p), eye(p);
                zeros(p,m), eye(p), zeros(p, p)];

% Then we prepare the gain matrix, so that it receives as inputs u_sys_K=y_sys_kest = [yhat; xhat ; e_int ; y],
% and it provides as outputs the control input and the residual y_sys2 = [u; y_r] = [u; y-yhat];
sys_K= [zeros(m,p) -Klq zeros(m,p); 
        -eye(p) zeros(p,n+p) eye(p)]; % y-y_hat

% Now we construct sys2 with the controller and detector.
sys2 = sys_K*sys_kest;

%% 3) Construct the closed-loop system 
nu=m;
ny = m+p+p;
sys = lft(sysmp_int_states_attack_d,sys2,nu,ny); % This feedback loop connects the first nu outputs of sys2 to the last nu inputs of sys1 (signals u), and the last ny outputs of sys1 to the first ny inputs of sys2 (signals y). The resulting system sys maps the input vector [w1 ; w2] to the output vector [z1 ; z2].

%In case we wish to have the performance and the detection systems, we can
%obtain them as:
sys_p = [eye(n), zeros(n,m)]*sys;
sys_r = [zeros(m,n), eye(m)]*sys;