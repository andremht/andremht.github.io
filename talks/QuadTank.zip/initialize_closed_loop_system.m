
s=tf('s');

type = 'nmp'; % non-minimum phase
%type = 'mp';


if strcmp(type,'mp')
    
    u10 =7.5;
    u20 =7.5;
    [~,~,~,~,~,~,~,sysmp] = initial_quadtank_nonlinear(type,u10,u20);

else
    
    u10 =5;
    u20 =5;
    [~,~,~,~,~,~,~,sysmp] = initial_quadtank_nonlinear(type,u10,u20);
    
end


Gmp = tf(sysmp);            % transfer function
[A,B,C,D] = ssdata(sysmp);
n =size(A,1); % states
p = size(C,1); % outputs 
m= size(B,2); % inputs

%% add integral states
A_aug = [A zeros(n,2); -C zeros(2,2)];
B_aug = [B; zeros(2,m)];
Br_aug = [zeros(n,2);eye(p)]; %input matrix for the output-reference signal.
C_aug = [C zeros(p, 2);
        zeros(2,n) eye(2)];
D_aug=zeros(p+2, m);
%
sysmp_aug = ss(A_aug,B_aug,C_aug,D_aug);

%% Define weights in continuous-time

if strcmp(type,'mp')
%% weights giving a control signal above 10V for the following reference:
%
ki = 10;
Qx = 50*blkdiag(eye(2), zeros(2,2));
Qz = ki*eye(2);
Q = blkdiag(Qx,Qz);
Qu=20*eye(2);


else
    % non-minimum phase
ki = 1;
Qx = 40*blkdiag(eye(2), zeros(2,2));
Qz = ki*eye(2);
Q = blkdiag(Qx,Qz);
Qu=20*eye(2);
end



%% Discretization
Ts = 2; % sampling time
sysmp_d = c2d(sysmp,Ts,'zoh');
sysmp_aug_d = c2d(sysmp_aug,Ts,'zoh');
sysmp_r_aug_d = c2d(ss(A_aug,Br_aug,C_aug,D_aug),Ts,'zoh'); % system with the reference signal as input
Br_aug_d = sysmp_r_aug_d.b;

% Convert costs from CT to DT
[Q_d,R_d,N_d] = discretize_cost( A_aug,B_aug, Q,Qu,zeros(n+p,m),Ts );

%% solve riccati equation and obtain L and S
[Klq,S,e] = lqi(sysmp_d,Q_d,R_d,N_d);
Sx = S; 

%% sets up the setpoint variables
[x0,u0, y0,An,Bn, Atap, Dcup] = initial_quadtank_nonlinear(type,u10, u20);
ub=15; % upper limit of the control signal
ul=0; % lower limit of the control signal



%% Kalman filter design
[A,B,C,D] =ssdata(sysmp_d);

Qv=[];
G = B;
H= zeros(p,size(G,2));
Qn=eye(size(G,2))*0.01;
Rn = eye(p)*0.0025;

sys_tmp = ss(A*1,[B G]*1,C,[D H],Ts);
[kest,L,P,M,Z] = kalman(sys_tmp,Qn,Rn,'current'); %inputs [u;y], outputs [yhat; xhat]

sys_est = [zeros(4,2) eye(4)]*kest;

% set up the simulation environment
sys_int = ss(eye(2),Ts*eye(2),eye(2),zeros(2),Ts);
F=sys_est;
G=sysmp;