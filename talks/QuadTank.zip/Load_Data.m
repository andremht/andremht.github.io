%addpath('MPC','Quad Tank system');

clear; clc;
s=tf('s');

%% %%%%%%%%%
% possible flags to control the type of system

type = 'nmp';
%type = 'mp';

flag_time = 'discrete';
    Ts = 2;

flag_time = 'continuous';
Ts = 0;

dt = max(Ts,1e-1);

%flag_;

%% Equilibrium and horizon

if strcmp(type,'mp')
    
    u10 =7.5; %7.5
    u20 =7.5;
    [~,~,~,~,~,~,~,sysmp] = initial_quadtank_nonlinear(type,u10,u20);

else
    
    u10 =5;
    u20 =5;
    [~,~,~,~,~,~,~,sysmp] = initial_quadtank_nonlinear(type,u10,u20);
    
end

Np = 10;    % prediction horizon
[x0,u0, y0,An,Bn, Atap, Dcup] = initial_quadtank_nonlinear(type,u10, u20); % equilibrium


ub=15;
    % ub=12;
    ul=0;

%%
Gmp = tf(sysmp);
n =size(sysmp.a,1); % states
p = size(sysmp.c,1); % outputs 
m= size(sysmp.b,2); % inputs
[A,B,C,D] = ssdata(sysmp);
Br = [zeros(n,p);eye(p)];

%% add integral states
A_aug = [A zeros(n,p); -C zeros(p,p)];
B_aug = [B; zeros(p,m)];
Br_aug = [zeros(n,p);eye(p)]; %input matrix for the output-reference signal.
C_aug = [C zeros(p, p)];
D_aug=zeros(p, m);
%
sysmp_aug = ss(A_aug,B_aug,C_aug,D_aug);

%% Define weights in continuous-time

if strcmp(type,'mp')
%% weights giving a control signal above 10V for the following reference:
% [y0(1) - 0.5*double(ref.time>100);
% y0(2) + 0.5*double(ref.time>600)];
%
ki = 0.1*1;
% Qx = 50*blkdiag(eye(2), zeros(2,2));
Qx = 50*blkdiag(eye(2), eye(2));
Qz = ki*eye(p);
Q = blkdiag(Qx,Qz);
Qu=20*eye(m);


else
    % non-minimum phase
ki = 1;
Qx = 40*blkdiag(eye(2), zeros(2,2));
Qz = ki*eye(p);
Q = blkdiag(Qx,Qz);
Qu=10*eye(m);
end



%% Discretization
if strcmp(flag_time , 'discrete')
    sysmp_d = c2d(sysmp,Ts,'zoh');
    sysmp_aug_d = c2d(sysmp_aug,Ts,'zoh');
    sysmp_r_aug_d = c2d(ss(A_aug,Br_aug,C_aug,D_aug),Ts,'zoh'); % system with the reference signal as input
    Br_aug_d = sysmp_r_aug_d.b;
    
    % Convert costs from CT to DT
    [Q_d,R_d,N_d] = discretize_cost( A_aug,B_aug, Q,Qu,zeros(n+p,m),Ts );
    
    % [Klq,S,e] = lqrd(sysmp_d,Q_d,Qu_d,N_d);
    
    
    %% solve riccati equation and obtain L and S
    [Klq,S,e] = lqi(sysmp_d,Q_d,R_d,N_d);
    Sx = S;
    
    
    %% sets up the variables for the MPC solver
    [Ahat,Bhat, Brhat,Qhat, Quhat, Hhat]=mpc_setup(sysmp_aug_d, Q_d, R_d, Sx, Np,Br_aug_d); % sets up the prediction and weight matrices
    
    
    
    umax = [ub;ub]-u0;
    umin = [ul; ul]-u0;
    
    ymax = [25; 25]*0.2-y0;
    ymin = [0; 0]-y0;
    
    uref=[0;0];
    uref = kron(ones(Np,1), uref);
    
    umin = kron(ones(Np,1), umin);
    umax = kron(ones(Np,1), umax);
    
    ymin = kron(ones(Np,1), ymin);
    ymax = kron(ones(Np,1), ymax);
end

if strcmp(flag_time , 'continuous')
%% solve riccati equation and obtain L and S
    [Klq,S,e] = lqi(sysmp,Q,Qu,zeros(n+p,m));
    Sx = S;
end
%% Kalman filter design
if strcmp(flag_time , 'discrete')
    [A,B,C,D] =ssdata(sysmp_d);
else
    [A,B,C,D] =ssdata(sysmp);
end

Qv=[];
% G = eye(n,n);
G = B;
H= zeros(p,size(G,2));
Qn=eye(size(G,2))*0.01;
Rn = eye(p)*0.0025;

sys_tmp = ss(A*1,[B G]*1,C,[D H],Ts);
[kest,L,P,M,Z] = kalman(sys_tmp,Qn,Rn,'current'); %inputs [u;y], outputs [yhat; xhat]

sys_est = [zeros(4,2) eye(4)]*kest;

% set up the simulation environment

sys_int = ss(eye(2),Ts*eye(2),eye(2),zeros(2),Ts);
F=sys_est;
G=sysmp;

%% Closed-loop model
ny=p;
nx=n;
nu = p;
np = nx + nu; % performance output

[V,E] = svd(Qx);
nr = min(find(diag(E)==0))-1;
CJ = sqrt(E(1:nr,1:nr))*V(:,1:nr)';

[V,E] = svd(Qu);
nr = min(find(diag(E)==0))-1;
if isempty(nr)
    DJ = sqrt(E)*V';
else
    DJ = sqrt(E(1:nr,1:nr))*V(:,1:nr)';
end

nJx = size(CJ, 1);
nJu = size(DJ, 1);

Cp = [CJ; zeros(nJu,nx)];
Dp = [zeros(nJx,nu); DJ];

% Inx = eye(nx);
% Cp = Inx(1:nx,:);              % performance measured by the states.
% Dp = zeros(nx,size(Bcl,2));

%sys_tmp = ss(A,B,C ,D,Ts);
Ba = [B zeros(nx,ny)];
Da = [D eye(ny)];
sys_tmp = ss(A,[B Ba],[C; Cp],[D Da; Dp, Dp, zeros(size(Dp,1),ny)],Ts);
Feedin = [1:nu];
Feedout = [1:ny];

%
Controller = lqgtrack(kest,Klq,'1dof'); 

Gc = feedback(sys_tmp,Controller,Feedin, Feedout, -1); % top u and y are the control and meas. Bottom measurements are the performance, bottom controls are the attacks.

% A matrix
Acl = Gc.a;
ncl = size(Acl,1);
Incl = eye(ncl);

nbcl = size(Gc.b,2);
Inbcl = eye(nbcl);

% %%%% ATTACK vectors
% Gamma = Inbcl(:,[3, 4, 5, 6]); % the selection matrix for the attacks.
%3 - actuator 1 
%4 - actuator 2
%5 - sensor 1
%6 - sensor 2
Gamma = Inbcl(:,[3,6]); % gives a nice "slow" unstable zero - incipient attack?
 Gamma = Inbcl(:,[3,5]); % gives a nice "slow" unstable zero 
% Gamma = Inbcl(:,[3,4]); % gives a nice "slow" unstable zero -  even with estimates added to the output
% Gamma = Inbcl(:,[4,5]); % gives a nice "slow" unstable zero

Gamma = Inbcl(:,[5]);
%Gamma = Inbcl(:,[5,6]);

Bcl = Gc.b*Gamma;

%%%%%%%%%%%%%%%%%%%%%%%%% check the performance output!!!
Cp = Gc.c;
Dp = Gc.d*Gamma;

%Cp(1:ny,:) = []; % removes the measurements. Output is the LQ output.
%Dp(1:ny,:) = []; %


%Cp = Incl(1:nx,:);              % performance measured by the states.
%Dp = zeros(nx,size(Bcl,2));

nacl = size(Bcl,2);

Cr = [Gc.c(1:ny,1:nx),  C,   zeros(ny,ncl -2*nx)];
Dr = Gc.d(1:ny,:)*Gamma;
% 
% %%%%%%%%%%%%%%%%%%%%%%%%%%
% % add output estimates to the output
% Cr = [Gc.c(1:ny,1:nx),  -C,   zeros(ny,ncl -2*nx) ; 
%       C*zeros(nx,nx),  C*eye(nx), C*zeros(nx,ncl -2*nx) ];
% Dr = [Gc.d(1:ny,:)*Gamma ;
%       C*zeros(nx,nacl) ];
%   %%%%%%%%%%%%%

sys_p=ss(Acl,Bcl,Cp,Dp,Ts);
sys_r=ss(Acl,Bcl,Cr,Dr,Ts);

%sys_weight = sys_tmp*[Inbcl(:,1:2), Gamma*inv(sys_r)];
%[Kopt, CLOpt, GAM]=hinfsyn(sys_weight,ny,nu);
%%% debug %% appears to check out...
% Gc2 = Gc;
% Gc2.B(1:8,5:6)=0;
% Gc2.D(:,5:6) = 0;
% 
% C2 = Gc2.C;
% C2(3:4,:)=[];
% C2 = [C2; Cr; Cp]
% D2 = Gc2.D;
% D2(3:4,:)=[];
% D2 = zeros(8,2);
% Gc2 = ss(Gc2.a, Gc2.b(:,5:6),C2, D2 )



%% % generate reference and disturbance signals
Tstop = 1000;
ref.time=0:dt:(Tstop+Np*dt);
ref.signals.values=[y0(1) - 0.0*double(ref.time>100);
                    y0(2) + 0.0*double(ref.time>600)];
                
tmp=kron(ref.signals.values(1,:)',[1;0]) + kron(ref.signals.values(2,:)',[0;1]);
for i=1:ceil(Tstop/dt)
   ref_prev.signals.values(:,i) =  tmp(2*i-1:2*(i+Np-1));
end
ref_prev.time=ref.time(1:size(ref_prev.signals.values,2))';
ref_prev.signals.values=ref_prev.signals.values';


ref.time=ref.time';
ref.signals.values=ref.signals.values';

% model disturbance
tap_valve = [0 0 1 0]*0;   % each entry should be between 0 (closed) and 1 (fully opened)
tap_start = 100;
tap_length = 100;

dtap.signals.values=kron(double(((ref.time>=tap_start)&(ref.time<=(tap_start+tap_length)))),tap_valve); 
dtap.signals.values=dtap.signals.values;
dtap.time=ref.time;

% pulse disturbance
cup_start = 10;
cup_length = dt; % length of the pulse in seconds
 cup_flow = [0 0 0 30*1];  % flow from the cup
%cup_flow = [30 30 30 30*1];  % flow from the cup

dcup.signals.values=kron(cup_flow,double(((ref.time>=cup_start)&(ref.time<=(cup_start+cup_length)))));
dcup.signals.values=dcup.signals.values;
dcup.time=ref.time;


%%%%%%%%%%%%%%%%%%%
%% open simulink models

% run closedloop_mpc_nonlinear
% 
% run closedloop_mpc_nonlinear_preview 
%                               

%% DoS
% run closedloop_LQG_nonlinear_DoS
%

%% Zero attack
% 
% Ad = sysmp_d.a;
% Bd = sysmp_d.b;
% Cd = sysmp_d.c;
% Dd = sysmp_d.d;
% 
% tmp=tzero(ss(Ad,Bd,Cd,Dd,Ts));
% nu = tmp(abs(tmp)>1);
% P=[nu*eye(4)-Ad  -Bd;
%   Cd             Dd];
% 
% tmp = null(P);
% z0 = tmp(1:4);
% g= tmp(5:end)/norm(tmp(5:end),2)*0.1;
% 
% run closedloop_LQG_nonlinear_Zero

%% Continuous-time
% run closedloop_LQG_nonlinear_continuous