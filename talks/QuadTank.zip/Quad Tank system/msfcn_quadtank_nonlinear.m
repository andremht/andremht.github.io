function msfcn_quadtank_nonlinear(block)
% Level-2 M file S-Function
%   Copyright 1990-2009 The MathWorks, Inc.
%   $Revision: 1.1.6.1 $ 

  setup(block);
  
%endfunction

function setup(block)
block.NumDialogPrms = 5; 
% x0 = block.DialogPrm(1).Data;
% A=block.DialogPrm(2).Data;
% B=block.DialogPrm(3).Data;
% Atap=block.DialogPrm(4).Data;
% Dcup=block.DialogPrm(5).Data;

  %% Register number of input and output ports
  block.NumInputPorts  = 3; % one input, one disturbance for the tap, one disturbance for adding a cup of water
  block.NumOutputPorts = 2;
  
  %% Setup functional port properties to dynamically
  %% inherited.
  block.SetPreCompInpPortInfoToDynamic;
  block.SetPreCompOutPortInfoToDynamic;
 
  block.InputPort(1).DirectFeedthrough = false; % input
  block.InputPort(1).Dimensions        = 2;
 
  block.InputPort(2).Dimensions        = 4;     % tap disturbance in each tank
  block.InputPort(2).DirectFeedthrough = false;
  
  block.InputPort(3).Dimensions        = 4;     % water cup disturbance in each tank
  block.InputPort(3).DirectFeedthrough = false;
  
  block.OutputPort(1).Dimensions       = 4;
  block.OutputPort(2).Dimensions       = 2;

  %% Set block sample time to inherited
  block.SampleTimes = [0 0];

  %% Run accelerator on TLC
  block.SetAccelRunOnTLC(true);
  
    %% Setup Dwork
  block.NumContStates = 4;

  %% Set the block simStateCompliance to default (i.e., same as a built-in block)
  block.SimStateCompliance = 'DefaultSimState';
  
  %% Register methods
  block.RegBlockMethod('InitializeConditions',    @InitConditions);  
  block.RegBlockMethod('Outputs',                 @Output);
  block.RegBlockMethod('Derivatives',                 @Derivatives);
 block.RegBlockMethod('SetInputPortSamplingMode', @SetInpPortFrameData);
  
%endfunction
function SetInpPortFrameData(block, idx, fd)
  block.InputPort(idx).SamplingMode = fd;
  block.OutputPort(1).SamplingMode  = fd;
  block.OutputPort(2).SamplingMode  = fd;


function InitConditions(block)
    block.ContStates.Data = block.DialogPrm(1).Data;
%     [15.947; 20.293; 6.188; 7.316];

  function Derivatives(block)  
  lb =0;
  ub = 25;
  u =  block.InputPort(1).Data;
  dtap =  block.InputPort(2).Data;
  dcup =  block.InputPort(3).Data;
    x = block.ContStates.Data;


for i=1:4
    if x(i)<0
        x(i)=0;
    end
end

% A=block.DialogPrm(2).Data;
% B=block.DialogPrm(3).Data;
% Atap=block.DialogPrm(4).Data;
% Dcup=block.DialogPrm(5).Data;

    dx = block.DialogPrm(2).Data* sqrt(x) + block.DialogPrm(3).Data*u + diag(dtap)*block.DialogPrm(4).Data*sqrt(x) + block.DialogPrm(5).Data*dcup;

for i=1:4  
  if ((x(i) <= lb) && (dx(i) < 0)) || ((x(i) >= ub) && (dx(i) > 0))
    block.Derivatives.Data(i) = 0;
  else
    block.Derivatives.Data(i) = dx(i);
  end
end

function Output(block)
  block.OutputPort(1).Data = block.ContStates.Data;
  block.OutputPort(2).Data = 0.2*block.ContStates.Data(1:2);
  
%endfunction

