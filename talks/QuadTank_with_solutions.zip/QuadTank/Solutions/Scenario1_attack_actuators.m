%% Undetectable attack on actuators
clc;




%% First we find the zero and construct the Rosenbrock matrix
nu_vec = tzero(sysmp_d); % compute the transmission zeros

[~,idx] = max(abs(nu_vec)); % find the on with maximum value
nu = nu_vec(idx);

% construct the Rosenbrock matrix
R_nu = [nu*eye(n) - sysmp_d.A , -sysmp_d.b;
    sysmp_d.c , sysmp_d.d];


%% Now we look into the Nullspace of the Rosenbrock matrix
K_R = null(R_nu);

x_0 = K_R(1:n);
g = K_R((n+1):end);

g= -g/norm(g); % normalize 


%% construct the attack
% a[k] = nu^k*g;

t=0:Ts:300;
k=0:1:round(300/Ts);

alph = 1; % the scaling of the attack signal
attack_signal = alph*nu.^k.*g;

y_m = lsim(sysmp_d,attack_signal, t);

i=1;
y_m_energy=[0];
y_m_peak=[0];

for i= 1:1:round(300/Ts)
    y_m_energy = [y_m_energy y_m_energy(end)+norm(y_m(i),2)];
    y_m_peak = [y_m_peak norm(y_m(i),2)];
end

%% plot the attack signal and the outputs. You can confirm that the diverging undetectable attack induces an impulse response on the system
figure(1)
plot(t, y_m_energy)

figure(2)
plot(t, y_m_peak)

figure(3)
plot(t, attack_signal)
