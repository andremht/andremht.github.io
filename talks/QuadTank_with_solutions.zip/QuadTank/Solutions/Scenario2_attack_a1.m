%%
clc;

[SV_p,W_p] = sigma(sys_p);
[SV_r, W_r ]= sigma(sys_r, W_p);

%%
figure(1)
loglog(W_p, SV_p)
hold on
loglog(W_r, SV_r)
hold off
%%
figure(2)
mu_w = SV_p./SV_r;
loglog(W_p, mu_w)
%% design the attack

[beta, idx] = max(mu_w);
w_max = W_p(idx);

t=0:Ts:300;
attack_signal = sin(w_max*t);

y_r = lsim(sys_r,attack_signal, t);

y_p = lsim(sys_p,attack_signal, t);

i=1;
y_r_energy=[0];
y_r_peak=[0];

y_p_energy=[0];
y_p_peak=[0];

for j=0:Ts:(300-1)
    y_r_energy = [y_r_energy y_r_energy(end)+norm(y_r(i),2)];
    y_r_peak = [y_r_peak norm(y_r(i),2)];

    y_p_energy = [y_p_energy y_p_energy(end)+norm(y_p(i),2)];
    y_p_peak = [y_p_peak norm(y_p(i),2)];
    i=i+1;
end
figure(3)
plot(t, y_r_energy)
hold on
plot(t, y_p_energy)
hold off


figure(4)
plot(t, y_r_peak)
hold on
plot(t, y_p_peak)
hold off