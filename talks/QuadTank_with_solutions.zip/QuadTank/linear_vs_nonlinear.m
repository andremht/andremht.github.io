%% nonlinear signals
% measurements and references
figure(1)
hold on
plot(measurement,'LineWidth', 1.5)
plot(reference, ':', 'LineWidth', 2)
hold off
legend('$y_1$', '$y_2$', '$r_1$', '$r_2$','fontsize',14,'interpreter','latex')
title('Measurement signals and References', 'fontsize',14)

% control signals

figure(2)
plot(control_signal,'LineWidth', 1.5)
legend('$u_1$', '$u_2$', 'fontsize',14,'interpreter','latex')
title('Control signals', 'fontsize',14)

%% Linear model
u = reshape(control_signal.data - u0, 2, []);
time = reshape(control_signal.time, 1, []);

[y,time,x] = lsim(sysmp_d, u ,control_signal.time); 

linear_measurements = y'+y0;

figure(5)
hold on
plot(measurement,'LineWidth', 1.5)
plot(time',linear_measurements(1,:), ':', 'LineWidth', 2)
plot(time',linear_measurements(2,:), ':','LineWidth', 2)
hold off
legend('$y_1$', '$y_2$', '$ylin_1$', '$ylin_2$','fontsize',14,'interpreter','latex')
