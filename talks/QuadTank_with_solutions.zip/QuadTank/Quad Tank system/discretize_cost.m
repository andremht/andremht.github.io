function [Qd,Rd,Nd] = discretize_cost( a,b, q,r,nn,Ts )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

Nx = size(a,1); 
Nu = size(b,2);

% Enforce symmetry and check positivity
q = (q+q')/2;
r = (r+r')/2;
vr = real(eig(r));
vqnr = real(eig([q nn;nn' r]));
if min(vr)<=0,
    ctrlMsgUtils.error('Control:design:lqr3','lqrd')
elseif min(vqnr)<-1e2*eps*max(0,max(vqnr)),
    ctrlMsgUtils.warning('Control:design:MustBePositiveDefinite','[Q N;N'' R]','lqrd')
end

% Determine discrete equivalent of continuous cost function 
% along with Ad,Bd matrices of discretized system
n = Nx+Nu;
Za = zeros(Nx); Zb = zeros(Nx,Nu); Zu = zeros(Nu);
M = [ -a' Zb   q  nn
      -b' Zu  nn'  r
      Za  Zb   a   b
      Zb' Zu  Zb' Zu];
phi = expm(M*Ts);
phi12 = phi(1:n,n+1:2*n);
phi22 = phi(n+1:2*n,n+1:2*n);
QQ = phi22'*phi12;
QQ = (QQ+QQ')/2;        % Make sure QQ is symmetric
Qd = QQ(1:Nx,1:Nx);
Rd = QQ(Nx+1:n,Nx+1:n);
Nd = QQ(1:Nx,Nx+1:n);
ad = phi22(1:Nx,1:Nx);
bd = phi22(1:Nx,Nx+1:n);
end

