function [x0,u0, y0,A,B] = setup_quadtank_nonlinear(type)

if strcmp(type, 'mp')
    % Operating levels of tanks
h10 = 18;      % i cm (nedre v�nstra tanken)
h20 = 18;      % i cm (nedre h�gra tanken)
h30 = 14;      % i cm (�vre v�nstra tanken)
h40 = 19;      % i cm (�vre h�gra tanken)

% Operating voltage of pumps
u10 = 7.5;     % i V
u20 = 7.5;     % i V

% Operating actuator proportional constants
k1 = 4.32;     % i cm^3/(Vs)
k2 = 3.74;     % i cm^3/(Vs)

% Outlet areas
a1 = 0.1678;   % i cm^2
a2 = 0.1542;   % i cm^2
a3 = 0.06743;  % i cm^2
a4 = 0.06504;  % i cm^2

% Valve settings
gam1 = 0.625;
gam2 = 0.625;


else
    
 % Operating levels of tanks
h10 = 15.947;      % i cm (nedre v�nstra tanken)
h20 = 20.293;      % i cm (nedre h�gra tanken)
h30 = 6.188;       % i cm (�vre v�nstra tanken)
h40 = 7.316;       % i cm (�vre h�gra tanken)

% Operating voltage of pumps
u10 = 7.5;     % i V
u20 = 7.5;     % i V


 % Operating actuator proportional constants
k1 = 4.32;     % i cm^3/(Vs)
k2 = 3.74;     % i cm^3/(Vs)

% Outlet areas
a1 = 0.1678;   % i cm^2
a2 = 0.1542;   % i cm^2
a3 = 0.1591;  % i cm^2
a4 = 0.1685;  % i cm^2

% Valve settings
gam1 = 1-0.625;
gam2 = 1-0.625;
end

% Cross section areas
A1 = 15.5179;   % cm^2
A2 = 15.5179;   % cm^2
A3 = 15.5179;   % cm^2
A4 = 15.5179;   % cm^2

% Sensor proportional constant
kc = 0.2;       % V/cm

% Acceleration of gravity
g = 981;        % cm/s^2

x0 = [h10;h20;h30;h40];

u0=[u10;u20];

A=[-a1/A1*sqrt(2*g)    0   a3/A1*sqrt(2*g)   0;
   0    -a2/A2*sqrt(2*g)   0    a4/A2*sqrt(2*g);
   0    0   -a3/A3*sqrt(2*g)   0;
   0   0   0    -a4/A4*sqrt(2*g) ];

B=[gam1*k1/A1 0;
    0           gam2*k2/A2;
    0       (1-gam2)*k2/A3;
    (1-gam1)*k1/A4     0];

x=-pinv(A)*B*u0;
x0=x.^2;
y0 = kc*x0(1:2);

  
