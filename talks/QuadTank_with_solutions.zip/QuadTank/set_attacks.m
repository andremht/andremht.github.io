T_attack_start = 100;


flag_DoS_attack = 0;
flag_replay_attack = 0;

flag_actuator_attack=1; % Flag for scenario 1
flag_actuator1_attack=0; % Flag for scenario 2

flag_sensor_attack=0;

%% DoS attack
mag_DoS_attack = 0.96; % this should be a value between 0 and 1, inclusive.


%% Actuator attacks - Scenarios 1 and 2 
a_signal=[];
a_signal.time=0:Ts:(Tstop+Np*Ts);
a_signal.signals.values=zeros(2,length(a_signal.time));


if flag_actuator1_attack == 1 
Scenario2_attack_a1; % create and code this script if you choose scenario 2

attack_signal = zeros(2,length(a_signal.time)); % modify this signal to implement the attack
alph = 0.7; % the scaling of the attack signal
attack_signal(1,:) = alph*sin(w_max*a_signal.time);

a_signal.signals.values=flag_actuator1_attack*attack_signal.*double(a_signal.time>=T_attack_start);
end

if flag_actuator_attack == 1 
Scenario1_attack_actuators;  % create and code this script if you choose scenario 1

alph = 1e-6; % the scaling of the attack signal

attack_signal = zeros(2,length(a_signal.time)); % modify this signal to implement the attack

k_a = 1e8;
    for i=1:1:length(a_signal.time)
        if a_signal.time(i) >= T_attack_start
            k_a = min(k_a, i);
            attack_signal(:,i) = alph*nu.^(i-k_a).*g;
        end
    end

a_signal.signals.values=attack_signal;
end


              
a_signal.time=a_signal.time';
a_signal.signals.values=a_signal.signals.values';


undetectable_attack = a_signal;

%% sensor attack
% here you need to modify the attack signal.
a_signal=[];
a_signal.time=0:Ts:(Tstop+Np*Ts);

% Plant model
Ad = sysmp_d.a;
Bd = sysmp_d.b;
Cd = sysmp_d.c;
Dd = sysmp_d.d;

Wo = gram(sysmp_d,'o');
[V, D] = eig(Wo);
[~,idx] =  min(diag(D));

Na = 3;
Ta = Tstop - T_attack_start;

x_0 = V(:,idx)*0.5;
x_k=x_0;
attack_signal=[];
i=0;

for k = 0:Ts:(T_attack_start-Ts)
    attack_signal=[attack_signal zeros(2,1)];
end

for k = T_attack_start:Ts:(Tstop+Np*Ts)
    i=i+1;
    a_k = Cd*x_k;
    attack_signal = [attack_signal a_k];
    
    x_k = Ad*x_k;
    if mod(i,Na) ==0
        x_k = x_0;
    end
end

a_signal.signals.values=flag_sensor_attack*attack_signal.*double(a_signal.time>=T_attack_start);
                
a_signal.time=a_signal.time';
a_signal.signals.values=a_signal.signals.values';

undetectable_sensor_attack = a_signal;

%% Replay attack
recorded_measurements  =a_signal; % here you need to load previously recorded "normal data" from the workspace