% This script generate the reference, disturbance, and attack signals.

%% % generate reference signal
Tstop = 1000;
Np=0;
ref=[];
ref_prev = [];

ref.time=0:Ts:(Tstop+Np*Ts);
ref.signals.values=[y0(1) - 0.2*flag_reference_change*double(ref.time>50 & ref.time<500);
                    y0(2) + 0.0*flag_reference_change*double(ref.time>600)];
                
tmp=kron(ref.signals.values(1,:)',[1;0]) + kron(ref.signals.values(2,:)',[0;1]);
for i=1:ceil(Tstop/Ts)
   ref_prev.signals.values(:,i) =  tmp(2*i-1:2*(i+Np-1));
end
ref_prev.time=ref.time(1:size(ref_prev.signals.values,2))';
ref_prev.signals.values=ref_prev.signals.values';


ref.time=ref.time';
ref.signals.values=ref.signals.values';



%% generate disturbance signals
% flag_pulse_disturbance =1; % 1 enables the pulse disturbance
%
% flag_leakage_fault =0; % 0 disables the model fault
% flag_sensor_fault =0; % 0 disables the sensor fault
% flag_actuator_fault =0; % 0 disables the actuator fault

%df_start = 300;

% leakage fault - corresponds to a outflow valve in some of the tanks
tap_valve = [0 0 mag_leakage_fault 0]*flag_leakage_fault;   % each entry should be between 0 (closed) and 1 (fully opened)
tap_start = df_start;
tap_length = floor((Tstop - tap_start));

dtap.signals.values=kron(double(((ref.time>=tap_start)&(ref.time<=(tap_start+tap_length)))),tap_valve); 
dtap.signals.values=dtap.signals.values;
dtap.time=ref.time;

% pulse disturbance - corresponds to an abrupt addition of water to each of
% the tanks
cup_start = df_start;
cup_length = Ts; % length of the pulse in seconds
cup_flow = [0 0 0 10*mag_pulse_disturbance*flag_pulse_disturbance];  % flow from the cup
dcup.signals.values=kron(cup_flow,double(((ref.time>=cup_start)&(ref.time<=(cup_start+cup_length)))));
dcup.signals.values=dcup.signals.values;
dcup.time=ref.time;

% actuator fault - corresponds to a loss of effectiveness
mag_actuator_fault = min(mag_actuator_fault,1);
mag_actuator_fault = max(mag_actuator_fault,0);

loeff_actuator = [0 mag_actuator_fault]*flag_actuator_fault; 
loeff_actuator_start = df_start;
loeff_actuator_length = floor((Tstop - loeff_actuator_start));

factuator.signals.values=kron(double(((ref.time>=loeff_actuator_start)&(ref.time<=(loeff_actuator_start+loeff_actuator_length)))),loeff_actuator); 
factuator.signals.values=factuator.signals.values;
factuator.time=ref.time;

% sensor fault - corresponds to a loss of effectiveness
mag_sensor_fault = min(mag_sensor_fault,1);
mag_sensor_fault = max(mag_sensor_fault,0);

loeff_sensor = [0 mag_sensor_fault]*flag_sensor_fault; 
loeff_sensor_start = df_start;
loeff_sensor_length = floor((Tstop - loeff_sensor_start));

fsensor.signals.values=kron(double(((ref.time>=loeff_sensor_start)&(ref.time<=(loeff_sensor_start+loeff_sensor_length)))),loeff_sensor); 
fsensor.signals.values=fsensor.signals.values;
fsensor.time=ref.time;


%%%%%%%%%%%%%%%%%%%
%% Zero attack
% Plant model
Ad = sysmp_d.a;
Bd = sysmp_d.b;
Cd = sysmp_d.c;
Dd = sysmp_d.d;


% compute the attack signal
attack_start = 100;
attack_length = Tstop - attack_start; % duration of the attack in seconds

% %%%%%%%%%%%%%%% UPDATE THE CODE HERE

attack_signal = zeros(501, 2); 
% attack_signal must be a Z x Y matrix, where Z is the length of ref.time,
% and Y is the number of compromised channels
% The Simulink model is configured so that both actuators are attacked, but
% you can change this if you want.

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% generates the attack signal applied to the plant at time t = attack_start
% the signal is truncated for t < attack_start
ZD_attack.signals.values= attack_signal.*double(((ref.time>=attack_start)&(ref.time<=(attack_start+attack_length))));
ZD_attack.signals.values=ZD_attack.signals.values;
ZD_attack.time=ref.time;